<?php

defined("ABSPATH") || exit;

/**
 * Variables
 *
 * @var \Duplicator\Core\Views\TplMng  $tplMng
 * @var array<string, mixed> $tplData
 */
?>
<p>
    <?php
    _e(
        'With manual transfers you can upload your backup to remote storages even after you have created them.',
        'duplicator'
    );
    ?>
</p>