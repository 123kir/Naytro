<?php
HtmlWpf::echoEscapedHtml(DispatcherWpf::applyFilters('filtersHtml', $this->html));
