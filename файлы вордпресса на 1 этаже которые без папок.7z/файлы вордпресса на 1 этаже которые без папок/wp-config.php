<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'qwq' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'qwq' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', 'EnV7d3gc6ua5.JAY' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'oY}qT5i,z*z`d`Y>b;h54j[WD(N`6I*S7Q>7S;p;tuP}y=6zMd[_h:x#l1kwOGda' );
define( 'SECURE_AUTH_KEY',  'Nc`1Nck:5EC^J#xdX&we@zquFl&MLpfLCs)4uq+s(NXDwxJ4d pdu}w~[;JA<z^Z' );
define( 'LOGGED_IN_KEY',    'ISMaWw$68qLIi4I_[AI@8n~78{$^sCE/eggr,G2&=ovW7_b6=[S wy5p9o<}>2N+' );
define( 'NONCE_KEY',        'd)Vg2Cz-g{0GaS-AnJKY,qCzQFVm&t6n| tUCoBQ?P5wA8Fp+{F<w~Uyw.j]D@B}' );
define( 'AUTH_SALT',        'Q-B=u`2YRImtS&D2)`:{j5`ClUJt;Dg(na;2Q{h]&x/-K8CRdLV$1o#jg4#}54!z' );
define( 'SECURE_AUTH_SALT', 'Y(DF6JLQ7_fK{iEijgyHp8A<%vvx7RJ[aA+L;Rn1([y$3~^)LGv9Y;qw!8ED2dA/' );
define( 'LOGGED_IN_SALT',   '}dexW~Qn#3]8k[8Hbxpu=%3]_;FU:5Q&_7Rf()g].:y)]z}E!H2{FM]/S)EN1&j ' );
define( 'NONCE_SALT',       'y]VQ.bhiTlPC[!q&Pzr&+EO@((N s^0o*: ^TC WuEN$-9O,m[=?N5H~#U`Mi@+ ' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
