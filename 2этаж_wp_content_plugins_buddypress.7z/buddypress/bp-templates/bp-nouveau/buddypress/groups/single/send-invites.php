<?php
/**
 * BuddyPress - Groups Send Invites
 *
 * @since 3.0.0
 * @version 3.0.0
 */
// Runs do_action & calls common/js-templates/invites/index
bp_nouveau_group_invites_interface();
