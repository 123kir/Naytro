<?php return array('dependencies' => array(), 'version' => '54eaee4ba109f65e1a8c');
