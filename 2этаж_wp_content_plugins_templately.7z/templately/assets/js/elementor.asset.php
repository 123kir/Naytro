<?php return array('dependencies' => array('wp-i18n'), 'version' => '8306b8d531c000016c29');
