<?php return array('dependencies' => array(), 'version' => '70c80ab41cd1e986c449');
