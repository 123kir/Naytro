<?php
	defined('ABSPATH') or die( 'Access denied!' ); // Avoid direct file request
?>

<div class="templately-admin-body">
    <div id="templatelyAdmin">
        <div class="templately-admin-preloader">
			<svg viewBox="0 0 512 512" width="50px" xmlns="http://www.w3.org/2000/svg"><circle cx="90.5" cy="454.8" fill="#ffb45a" r="57.2"></circle><circle cx="256" cy="454.8" fill="#ff7b8e" r="57.2"></circle><circle cx="421.5" cy="454.8" fill="#5ac0ff" r="57.2"></circle><path d="M356.5 94.5c-3.1 0-6.1.2-9.1.4C335 40.6 286.4 0 228.3 0c-15.3 0-29.9 2.8-43.4 8 0 15.3.1 32.9.2 40.4 15.6.1 45.8.2 59.1.2v57.8h-58.8v97.7h60.5c-1.7 4.3-4.3 10.7-5.4 13.2-11 26.5-38.3 41.3-66.6 36.2-26.9-4.9-46.9-27.8-48.4-55.9-.4-8.2-.2-16.5-.2-24.7V106h-20.7c-41.8 19.4-70.9 61.7-70.9 110.8 0 67.5 54.7 122.2 122.2 122.2h202c66.9-.7 120.8-55.1 120.8-122.2 0-67.5-54.7-122.3-122.2-122.3z" fill="#5633d1"></path></svg>
			<p>Loading...</p>
        </div>
    </div>
</div>